import React from 'react';
export const AdminPortalView: React.FC = () => null;
export const AdminView: React.FC = () => null;
